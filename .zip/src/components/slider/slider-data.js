// https://i.ibb.co/g4RDXbZ/phone2.jpg

export const sliderData = [
  {
    image: "https://i.ibb.co/D1TvpVL/white-shoe.jpg",
    heading: "Shoes Villa",
    desc: "Up to 30% off on all onsale proucts.",
  },
  {
    image: "https://i.ibb.co/Bz5v6xs/gadget.jpg",
    heading: "Hot Gadgets",
    desc: "Up to 30% off on all onsale proucts.",
  },
  {
    image: "https://i.ibb.co/RThT5KJ/men-wear.jpg",
    heading: "Men Fashion",
    desc: "Up to 30% off on all onsale proucts.",
  },
  {
    image: "https://i.ibb.co/ZVQHTjk/phone.jpg",
    heading: "Android Phones",
    desc: "Up to 30% off on all onsale proucts.",
  },
  {
    image: "https://i.ibb.co/tYcmTKr/blue-shoe.jpg",
    heading: "Nike Sneakers",
    desc: "Up to 30% off on all onsale proucts.",
  },
];
